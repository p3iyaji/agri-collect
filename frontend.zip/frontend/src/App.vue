<script setup>
import { onBeforeUnmount, onMounted, watch } from 'vue';
import AdminMenu from '@/components/AdminMenu.vue';
import SyncBadge from '@/components/SyncBadge.vue';
import WorkspaceSwitcher from '@/components/WorkspaceSwitcher.vue';
import { useMobileSync } from '@/composables/useMobileSync';
import { useAuthStore } from '@/stores/auth';

const auth = useAuthStore();
const sync = useMobileSync({ intervalMs: 30_000 });

// Run the sync engine for the whole session (web + Capacitor webview):
// periodic outbox flushes, online/offline triggers, connectivity state.
// Watched so the engine starts after a fresh login, not just restored sessions.
watch(
    () => auth.isAuthed,
    (isAuthed) => {
        if (isAuthed) {
            sync.start();
        } else {
            sync.stop();
        }
    },
    { immediate: true },
);

onBeforeUnmount(() => {
    sync.stop();
});
</script>

<template>
    <div class="min-h-screen bg-slate-950 text-slate-100">
        <header class="sticky top-0 z-20 border-b border-slate-800 bg-slate-900/95 backdrop-blur">
            <div class="mx-auto flex max-w-6xl flex-wrap items-center gap-3 px-4 py-3">
                <router-link to="/dashboard" class="flex items-center gap-2 text-lg font-bold tracking-tight">
                    <img
                        v-if="auth.activeAccount?.logo_url"
                        :src="auth.activeAccount.logo_url"
                        :alt="auth.activeAccount.name"
                        class="h-8 w-8 rounded-md object-cover"
                    />
                    <span v-else class="text-emerald-400">🌾</span>
                    <span>{{ auth.activeAccount?.logo_url ? auth.activeAccount.name : 'DigitCapture' }}</span>
                </router-link>

                <template v-if="auth.isAuthed">
                    <WorkspaceSwitcher />
                    <SyncBadge />
                    <AdminMenu />
                    <div class="ml-auto flex items-center gap-3">
                        <span class="hidden text-sm text-slate-400 sm:inline">{{ auth.user?.name }}</span>
                        <button class="btn-ghost" @click="auth.logout()">Log out</button>
                    </div>
                </template>
            </div>

            <nav v-if="auth.isAuthed" class="mx-auto flex max-w-6xl gap-1 px-4 pb-2 text-sm">
                <router-link
                    to="/dashboard"
                    class="rounded-md px-3 py-1.5 transition hover:bg-slate-800"
                    active-class="!bg-slate-800 !text-emerald-300"
                >
                    Dashboard
                </router-link>
                <router-link
                    to="/forms"
                    class="rounded-md px-3 py-1.5 transition hover:bg-slate-800"
                    active-class="!bg-slate-800 !text-emerald-300"
                >
                    Forms
                </router-link>
                <router-link
                    to="/submissions"
                    class="rounded-md px-3 py-1.5 transition hover:bg-slate-800"
                    active-class="!bg-slate-800 !text-emerald-300"
                >
                    Submissions
                </router-link>
            </nav>
        </header>

        <main class="mx-auto max-w-6xl px-4 py-6">
            <router-view />
        </main>
    </div>
</template>
