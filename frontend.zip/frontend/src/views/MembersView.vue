<script setup>
import { computed, onMounted, reactive, ref } from 'vue';
import AdminTabs from '@/components/AdminTabs.vue';
import { api } from '@/services/api';
import { useAuthStore } from '@/stores/auth';

const auth = useAuthStore();
const base = computed(() => `/workspaces/${auth.activeAccount.id}`);

const members = ref([]);
const roles = ref([]);
const loading = ref(true);
const error = ref(null);
const savingId = ref(null);

const invite = reactive({ email: '', name: '', role_id: '' });
const inviting = ref(false);
const inviteError = ref(null);
const newCredentials = ref(null);
const copied = ref(false);

async function load() {
    loading.value = true;
    error.value = null;

    try {
        const [membersRes, rolesRes] = await Promise.all([
            api.get(`${base.value}/members`),
            api.get(`${base.value}/roles`),
        ]);

        members.value = membersRes.data.data ?? [];
        roles.value = rolesRes.data.data ?? [];
    } catch (loadError) {
        error.value = loadError?.response?.data?.error ?? loadError?.message;
    } finally {
        loading.value = false;
    }
}

async function inviteMember() {
    inviting.value = true;
    inviteError.value = null;

    try {
        const response = await api.post(`${base.value}/members`, {
            email: invite.email,
            name: invite.name || undefined,
            role_id: invite.role_id ? Number(invite.role_id) : undefined,
        });

        if (response.data.meta?.created_user) {
            newCredentials.value = {
                email: response.data.data.attributes.email,
                password: response.data.meta.temp_password,
            };
            copied.value = false;
        }

        invite.email = '';
        invite.name = '';
        invite.role_id = '';

        await load();
    } catch (err) {
        inviteError.value =
            err?.response?.data?.error ?? err?.response?.data?.message ?? err?.message;
    } finally {
        inviting.value = false;
    }
}

async function patchMember(member, payload) {
    savingId.value = member.id;

    try {
        await api.patch(`${base.value}/members/${member.id}`, payload);
        await load();
    } catch (err) {
        error.value = err?.response?.data?.error ?? err?.message;
        await load();
    } finally {
        savingId.value = null;
    }
}

function changeRole(member, roleId) {
    patchMember(member, { role_id: roleId === '' ? null : Number(roleId) });
}

function toggleStatus(member) {
    patchMember(member, {
        status: member.attributes.status === 'active' ? 'suspended' : 'active',
    });
}

async function removeMember(member) {
    const ok = window.confirm(
        `Remove ${member.attributes.name} from this workspace? They will lose access immediately.`,
    );

    if (!ok) {
        return;
    }

    savingId.value = member.id;

    try {
        await api.delete(`${base.value}/members/${member.id}`);
        await load();
    } catch (err) {
        error.value = err?.response?.data?.error ?? err?.message;
    } finally {
        savingId.value = null;
    }
}

async function copyPassword() {
    if (!newCredentials.value?.password) {
        return;
    }

    try {
        await navigator.clipboard.writeText(newCredentials.value.password);
        copied.value = true;
    } catch {
        copied.value = false;
    }
}

onMounted(load);
</script>

<template>
    <div>
        <h1 class="mb-4 text-xl font-bold">Members</h1>
        <AdminTabs />

        <p v-if="error" class="card mb-4 text-red-300">{{ error }}</p>
        <p v-else-if="loading" class="text-slate-400">Loading…</p>

        <div v-else class="space-y-4">
            <!-- Invite -->
            <div class="card">
                <h2 class="mb-3 text-sm font-semibold">Invite a member</h2>
                <div class="flex flex-wrap items-end gap-3">
                    <div>
                        <label class="mb-1 block text-xs text-slate-400">Email</label>
                        <input v-model="invite.email" type="email" required class="input !w-56" placeholder="person@example.org" />
                    </div>
                    <div>
                        <label class="mb-1 block text-xs text-slate-400">Name (new users only)</label>
                        <input v-model="invite.name" class="input !w-44" />
                    </div>
                    <div>
                        <label class="mb-1 block text-xs text-slate-400">Role</label>
                        <select v-model="invite.role_id" class="input !w-40">
                            <option value="">No role</option>
                            <option v-for="role in roles" :key="role.id" :value="role.id">{{ role.attributes.name }}</option>
                        </select>
                    </div>
                    <button class="btn" :disabled="inviting || !invite.email" @click="inviteMember">
                        {{ inviting ? 'Inviting…' : 'Invite' }}
                    </button>
                </div>
                <p v-if="inviteError" class="mt-2 text-sm text-red-400">{{ inviteError }}</p>
            </div>

            <!-- One-time password for a freshly created user -->
            <div v-if="newCredentials" class="card border-amber-700/70">
                <p class="text-sm">
                    Created <strong>{{ newCredentials.email }}</strong> — share this one-time
                    password (shown only once):
                </p>
                <div class="mt-2 flex flex-wrap items-center gap-2">
                    <code class="rounded bg-slate-950 px-3 py-1 font-mono text-amber-300">
                        {{ newCredentials.password }}
                    </code>
                    <button class="btn-ghost text-xs" @click="copyPassword">
                        {{ copied ? 'Copied ✓' : 'Copy' }}
                    </button>
                    <button class="btn-ghost text-xs" @click="newCredentials = null">Dismiss</button>
                </div>
            </div>

            <!-- Member list -->
            <div class="card overflow-x-auto !p-0">
                <table class="w-full">
                    <thead>
                        <tr class="border-b border-slate-800">
                            <th class="th">Name</th>
                            <th class="th">Email</th>
                            <th class="th">Role</th>
                            <th class="th">Status</th>
                            <th class="th">Joined</th>
                            <th class="th text-right">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr
                            v-for="member in members"
                            :key="member.id"
                            class="border-b border-slate-800/60 last:border-0"
                        >
                            <td class="td font-medium">
                                {{ member.attributes.name }}
                                <span v-if="member.attributes.is_you" class="text-xs text-emerald-400">(you)</span>
                            </td>
                            <td class="td text-slate-400">{{ member.attributes.email }}</td>
                            <td class="td">
                                <select
                                    class="input !w-32 !py-1 text-xs"
                                    :value="member.attributes.role_id ?? ''"
                                    :disabled="savingId === member.id"
                                    @change="(e) => changeRole(member, e.target.value)"
                                >
                                    <option value="">No role</option>
                                    <option v-for="role in roles" :key="role.id" :value="role.id">
                                        {{ role.attributes.name }}
                                    </option>
                                </select>
                            </td>
                            <td class="td">
                                <span
                                    class="rounded-full px-2 py-0.5 text-xs"
                                    :class="{
                                        'bg-emerald-900/60 text-emerald-300': member.attributes.status === 'active',
                                        'bg-slate-800 text-slate-400': member.attributes.status !== 'active',
                                    }"
                                >
                                    {{ member.attributes.status }}
                                </span>
                            </td>
                            <td class="td text-xs text-slate-400">
                                {{ member.attributes.joined_at?.slice(0, 10) }}
                            </td>
                            <td class="td text-right whitespace-nowrap">
                                <button
                                    class="mr-2 text-xs text-amber-300 hover:underline"
                                    :disabled="savingId === member.id"
                                    @click="toggleStatus(member)"
                                >
                                    {{ member.attributes.status === 'active' ? 'Suspend' : 'Reactivate' }}
                                </button>
                                <button
                                    class="text-xs text-red-400 hover:underline"
                                    :disabled="savingId === member.id"
                                    @click="removeMember(member)"
                                >
                                    Remove
                                </button>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</template>
