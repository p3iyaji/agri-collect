<script setup>
import { computed, onMounted, reactive, ref, watch } from 'vue';
import DateRangePicker from '@/components/DateRangePicker.vue';
import { api } from '@/services/api';
import { useAuthStore } from '@/stores/auth';

const auth = useAuthStore();
const canWrite = computed(() => auth.hasPermission('submissions.write'));

const forms = ref([]);
const rows = ref([]);
const total = ref(0);
const page = ref(1);
const perPage = 25;

const loading = ref(false);
const exporting = ref(false);
const error = ref(null);

const filters = reactive({
    form_id: '',
    from: '',
    to: '',
    q: '',
});

function queryParams(targetPage = page.value) {
    const params = { page: targetPage, per_page: perPage };

    if (filters.form_id) {
        params.form_id = filters.form_id;
    }
    if (filters.from) {
        params.from = filters.from;
    }
    if (filters.to) {
        params.to = filters.to;
    }
    if (filters.q) {
        params.q = filters.q;
    }

    return params;
}

async function load() {
    loading.value = true;
    error.value = null;

    try {
        const response = await api.get('/submissions', { params: queryParams() });
        rows.value = response.data.data ?? [];
        total.value = response.data.meta?.total ?? 0;
    } catch (loadError) {
        error.value = loadError?.response?.data?.error ?? loadError?.message;
    } finally {
        loading.value = false;
    }
}

async function loadForms() {
    try {
        const response = await api.get('/forms');
        // Keep the full schema — the import panel uses it for the
        // template download and the column mapping preview.
        forms.value = (response.data.data ?? []).map((form) => ({
            id: form.id,
            name: form.attributes.name,
            schema: form.attributes.schema,
        }));
    } catch {
        // Non-fatal: filters just have no form options.
    }
}

function applyFilters() {
    page.value = 1;
    load();
}

function goToPage(target) {
    if (target < 1 || target > totalPages.value) {
        return;
    }
    page.value = target;
    load();
}

const totalPages = ref(1);

// Keep pagination in sync after each load.
function refreshPagination() {
    totalPages.value = Math.max(1, Math.ceil(total.value / perPage));
}

/**
 * Stream a CSV export from the workspace-scoped export endpoint.
 */
async function exportCsv() {
    exporting.value = true;
    error.value = null;

    try {
        const params = { format: 'csv' };
        if (filters.form_id) {
            params.form_id = filters.form_id;
        }
        if (filters.from) {
            params.date_from = filters.from;
        }
        if (filters.to) {
            params.date_to = filters.to;
        }

        const response = await api.get(
            `/workspaces/${auth.activeAccount.id}/exports/submissions`,
            { params, responseType: 'blob' },
        );

        const url = URL.createObjectURL(response.data);
        const anchor = document.createElement('a');
        anchor.href = url;
        anchor.download = `submissions_${auth.activeAccount.slug}_${new Date().toISOString().slice(0, 10)}.csv`;
        document.body.appendChild(anchor);
        anchor.click();
        anchor.remove();
        URL.revokeObjectURL(url);
    } catch (exportError) {
        error.value = `Export failed: ${exportError?.message}`;
    } finally {
        exporting.value = false;
    }
}

// Re-run pagination calc whenever the total changes.
watch(total, refreshPagination);

// -- CSV import ------------------------------------------------------------

const importOpen = ref(false);
const importFormId = ref('');
const importFile = ref(null);
const importHeader = ref([]);
const importing = ref(false);
const importError = ref(null);
const importResult = ref(null);

const importForm = computed(
    () => forms.value.find((form) => String(form.id) === String(importFormId.value)) ?? null,
);

/** Naive-but-quoted CSV header parse (preview only; the server is authoritative). */
function parseHeaderLine(line) {
    const cells = [];
    let cell = '';
    let inQuotes = false;

    for (const char of line) {
        if (inQuotes) {
            if (char === '"') {
                inQuotes = false;
            } else {
                cell += char;
            }
        } else if (char === '"') {
            inQuotes = true;
        } else if (char === ',') {
            cells.push(cell.trim());
            cell = '';
        } else {
            cell += char;
        }
    }

    cells.push(cell.trim());

    return cells;
}

async function onImportFile(event) {
    importFile.value = event.target.files?.[0] ?? null;
    importHeader.value = [];
    importResult.value = null;

    if (!importFile.value) {
        return;
    }

    try {
        const head = await importFile.value.slice(0, 65536).text();
        const firstLine = head.split(/\r?\n/, 1)[0];
        importHeader.value = parseHeaderLine(firstLine.replace(/^\uFEFF/, ''));
    } catch {
        importHeader.value = [];
    }
}

const importPreview = computed(() => {
    if (!importForm.value || importHeader.value.length === 0) {
        return null;
    }

    const fields = importForm.value.schema?.fields ?? [];
    const reserved = ['local_uuid', 'created_at'];
    const matched = {};
    const matchedColumns = new Set();

    for (const field of fields) {
        const column = importHeader.value.find(
            (cell) =>
                cell &&
                !reserved.includes(cell) &&
                (cell.toLowerCase() === String(field.name ?? '').toLowerCase() ||
                    cell.toLowerCase() === String(field.label ?? '').toLowerCase()),
        );

        if (column) {
            matched[field.name] = column;
            matchedColumns.add(column);
        }
    }

    return {
        matched,
        missingRequired: fields.filter((field) => field.required && !matched[field.name])
            .map((field) => field.label || field.name),
        extraColumns: importHeader.value.filter(
            (cell) => cell && !matchedColumns.has(cell) && !reserved.includes(cell),
        ),
    };
});

function downloadTemplate() {
    const form = importForm.value;

    if (!form) {
        return;
    }

    const fields = form.schema?.fields ?? [];
    const header = ['local_uuid', ...fields.map((field) => field.name)].join(',');
    const blob = new Blob([header + '\n'], { type: 'text/csv;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement('a');
    anchor.href = url;
    anchor.download = `${form.name.toLowerCase().replace(/[^a-z0-9]+/g, '_')}_import_template.csv`;
    document.body.appendChild(anchor);
    anchor.click();
    anchor.remove();
    URL.revokeObjectURL(url);
}

async function runImport() {
    importing.value = true;
    importError.value = null;
    importResult.value = null;

    try {
        const formData = new FormData();
        formData.append('form_id', importFormId.value);
        formData.append('csv', importFile.value);

        const response = await api.post(
            `/workspaces/${auth.activeAccount.id}/imports/submissions`,
            formData,
            { headers: { 'Content-Type': 'multipart/form-data' } },
        );

        importResult.value = response.data.data.attributes;
        importResult.value.error_rows = response.data.meta?.error_rows ?? [];
        load();
    } catch (importRequestError) {
        importError.value =
            importRequestError?.response?.data?.error ??
            importRequestError?.response?.data?.message ??
            importRequestError?.message;
    } finally {
        importing.value = false;
    }
}

onMounted(() => {
    loadForms();
    load();
});
</script>

<template>
    <div>
        <div class="mb-4 flex flex-wrap items-center justify-between gap-3">
            <h1 class="text-xl font-bold">Submissions</h1>
            <div class="flex gap-2">
                <button v-if="canWrite" class="btn-ghost" @click="importOpen = !importOpen; importResult = null">
                    ⬆ Import CSV
                </button>
                <button class="btn-ghost" :disabled="exporting" @click="exportCsv">
                    {{ exporting ? 'Exporting…' : '⬇ Export CSV' }}
                </button>
            </div>
        </div>

        <!-- Import panel -->
        <div v-if="importOpen && canWrite" class="card mb-4 space-y-3">
            <h2 class="text-sm font-semibold">Import CSV into a form</h2>
            <div class="flex flex-wrap items-end gap-3">
                <div>
                    <label class="mb-1 block text-xs text-slate-400">Target form</label>
                    <select v-model="importFormId" class="input !w-56">
                        <option value="">Choose…</option>
                        <option v-for="form in forms" :key="form.id" :value="form.id">{{ form.name }}</option>
                    </select>
                </div>
                <div>
                    <label class="mb-1 block text-xs text-slate-400">CSV file</label>
                    <input type="file" accept=".csv,text/csv" class="max-w-64 text-xs" @change="onImportFile" />
                </div>
                <button v-if="importForm" class="btn-ghost text-xs" @click="downloadTemplate">
                    ⬇ Template
                </button>
                <button
                    class="btn"
                    :disabled="importing || !importFormId || !importFile"
                    @click="runImport"
                >
                    {{ importing ? 'Importing…' : 'Import' }}
                </button>
            </div>

            <p class="text-xs text-slate-500">
                Header row maps to field names or labels. Optional columns:
                <code class="font-mono">local_uuid</code> (idempotency key) and
                <code class="font-mono">created_at</code>. Re-importing the same file does not create copies.
            </p>

            <!-- Mapping preview -->
            <div v-if="importPreview" class="flex flex-wrap gap-2 text-xs">
                <span
                    v-for="(column, name) in importPreview.matched"
                    :key="name"
                    class="rounded-full bg-emerald-900/50 px-2 py-0.5 text-emerald-300"
                >
                    {{ name }} ← {{ column }}
                </span>
                <span
                    v-for="name in importPreview.missingRequired"
                    :key="name"
                    class="rounded-full bg-red-900/50 px-2 py-0.5 text-red-300"
                >
                    missing required: {{ name }}
                </span>
                <span
                    v-for="column in importPreview.extraColumns"
                    :key="column"
                    class="rounded-full bg-slate-800 px-2 py-0.5 text-slate-400"
                >
                    ignored: {{ column }}
                </span>
            </div>

            <p v-if="importError" class="text-sm text-red-400">{{ importError }}</p>

            <!-- Result summary -->
            <div v-if="importResult" class="rounded-md border border-slate-700 bg-slate-950/60 p-3">
                <p class="text-sm">
                    <span class="text-emerald-300">{{ importResult.imported }} imported</span>
                    <span v-if="importResult.duplicates > 0" class="text-amber-300">
                        · {{ importResult.duplicates }} duplicates skipped
                    </span>
                    <span v-if="importResult.errors > 0" class="text-red-300">
                        · {{ importResult.errors }} errors
                    </span>
                    <span class="text-slate-400"> ({{ importResult.total_rows }} rows → {{ importResult.form_name }})</span>
                </p>
                <ul v-if="importResult.error_rows?.length > 0" class="mt-2 space-y-1 text-xs text-red-300">
                    <li v-for="rowError in importResult.error_rows" :key="rowError.row">
                        Row {{ rowError.row }}: {{ rowError.error }}
                    </li>
                </ul>
            </div>
        </div>

        <div class="card mb-4 flex flex-wrap items-end gap-3">
            <div>
                <label class="mb-1 block text-xs text-slate-400">Form</label>
                <select v-model="filters.form_id" class="input !w-48" @change="applyFilters">
                    <option value="">All forms</option>
                    <option v-for="form in forms" :key="form.id" :value="form.id">{{ form.name }}</option>
                </select>
            </div>
            <div>
                <label id="submissions-date-label" class="mb-1 block text-xs text-slate-400">Dates</label>
                <DateRangePicker
                    v-model:from="filters.from"
                    v-model:to="filters.to"
                    labelled-by="submissions-date-label"
                    @change="applyFilters"
                />
            </div>
            <div>
                <label class="mb-1 block text-xs text-slate-400">Search UUID</label>
                <input v-model="filters.q" class="input !w-44 font-mono" placeholder="local_uuid…" @change="applyFilters" />
            </div>
        </div>

        <p v-if="error" class="card mb-4 text-red-300">{{ error }}</p>
        <p v-else-if="loading" class="text-slate-400">Loading…</p>

        <div v-else class="card overflow-x-auto !p-0">
            <table class="w-full">
                <thead>
                    <tr class="border-b border-slate-800">
                        <th class="th">ID</th>
                        <th class="th">Form</th>
                        <th class="th">UUID</th>
                        <th class="th">By</th>
                        <th class="th">GPS</th>
                        <th class="th">Created</th>
                    </tr>
                </thead>
                <tbody>
                    <tr v-if="rows.length === 0">
                        <td colspan="6" class="td text-slate-400">No submissions yet.</td>
                    </tr>
                    <tr
                        v-for="row in rows"
                        :key="row.id"
                        class="border-b border-slate-800/60 last:border-0"
                    >
                        <td class="td">{{ row.id }}</td>
                        <td class="td">{{ row.attributes.form_name }}</td>
                        <td class="td max-w-44 truncate font-mono text-xs text-slate-400">
                            {{ row.attributes.local_uuid }}
                        </td>
                        <td class="td">{{ row.attributes.submitted_by ?? '—' }}</td>
                        <td class="td font-mono text-xs">
                            <template v-if="row.attributes.gps?.lat != null">
                                {{ row.attributes.gps.lat.toFixed(4) }}, {{ row.attributes.gps.lng.toFixed(4) }}
                            </template>
                            <template v-else>—</template>
                        </td>
                        <td class="td text-xs text-slate-400">{{ row.attributes.created_at?.replace('T', ' ').slice(0, 16) }}</td>
                    </tr>
                </tbody>
            </table>
        </div>

        <div v-if="totalPages > 1" class="mt-4 flex items-center gap-2 text-sm">
            <button class="btn-ghost" :disabled="page <= 1" @click="goToPage(page - 1)">← Prev</button>
            <span class="text-slate-400">
                Page {{ page }} of {{ totalPages }} ({{ total }} total)
            </span>
            <button class="btn-ghost" :disabled="page >= totalPages" @click="goToPage(page + 1)">Next →</button>
        </div>
    </div>
</template>
